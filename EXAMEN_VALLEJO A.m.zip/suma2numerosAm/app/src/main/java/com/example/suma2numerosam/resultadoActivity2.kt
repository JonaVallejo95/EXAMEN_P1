package com.example.suma2numerosam

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class resultadoActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado2)

        val textView1: TextView = findViewById(R.id.rfinal)
        val receivedMessage:String = intent.extras?.getString("EXTRA_MESSAGE").orEmpty()
        textView1.text = receivedMessage
    }
}